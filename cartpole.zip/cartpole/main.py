# The CartPole system is a classic problem of reinforcement learning. The system consist of a pole
# which acts like an inverted pendulum attached to a cart using a join.
# The system is controlled by applying a force of +1 and -1 to the cart.
# The force applied to the cart can be controlled and the purpose is to swing the pole upward and stabailize it.
# This must be done without the cart falling to the ground.
# At every step, the agent can choose to move the cart left or right
# and it receives a reward of 1 for every time step that the pole is balanced.
# If the pole ever deviates by more than 15 degrees fro upright, the procedure ends.


import gym
# The make method creates the environemnt that our agent will run.
# An environment is a problem with a minimal interface that an agent can interact with

env = gym.make('CartPole-v0')
#  We initialize the newly set environment by resetting it using the reset() method
env.reset()
# An initial observation is returned: this value represetns our initial state. At this point we will use a for loop
# to run an instance of the Cartpole-v0 environment for 1000 time steps rendering the environment at each step,
for i in range(1000):
    env.render()
    env.step(env.action_space.sample())
# Calling the render() method will visually display the current state
# while subsequent calls to env.step() will allow us to interact with the environment returning the new states
# in response to the actions with which we call it.
# In this way we have adopted random actions at each step. At this point it is certainly useful to know
# What actions we are doing on the environment to decide future actions. The step() method returns exactly this.
# In effect , this method will return the 4 values. The first value is the observation.
# Observation is an environment specific object representing your observation of the environment.
# The second value is the reward and it is the amount of reward achieve by the previous action.
# The scale varies between environment but the goal is ways to increase the total reward.
# The third value is the done and this determines whether it is time to reset the environment again.
# Most (but not all) tasks are divided into well-defined episodes and done being True indicates that the episode is terminated.
# The final value is the info. This shows you dianostic information that is useful for debugging and learning.
#  A window will be displayed that contains our system and this is not stable and will soon move out of the screen.
# This is because the cart is pushed randomly without taking into account the position of the pole.
# To solve this problem that is to balance the pole it is important to set the push in the opposite direction to the inclination of the pole.
# So we have to set only 2 actions -1 and 1, pushing the cart to the left and right.
# But to do so, we do need know the data deriving from the observation of the environment at all times.
# As mentioned before, these pieces of data are returned by the step() method.
# In particular they are contained in the observation object.
# This object contains cart position and velocity, pole angle and velocity at tip. And these values becone the input of the problem
# As we have also anticipated , the system is balanced by applying a push to the car. There are 2 possible options
# The first one is push the cart to the left and the second one is push the cart to the right.
# It is clear that this is a binary classification problem: 4 inputs and a single binary output.
# First let's consider how we can extract the values to be sued as input.
